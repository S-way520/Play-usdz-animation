import SwiftUI
import RealityKit
struct ContentView: View {
    var body: some View {
        RealityView()
            .edgesIgnoringSafeArea(.all)
    }
}
struct RealityView: UIViewRepresentable {
    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero, cameraMode: .ar, automaticallyConfigureSession: true)
        let anchorEntity = AnchorEntity(plane: .horizontal)
       guard let ARentity = try? ModelEntity.load(named: "toy_biplane_idle") else {
            fatalError("toy_biplane_idle model is not!")
        }
        ARentity.playAnimation(ARentity.availableAnimations[0].repeat(duration: .infinity), transitionDuration: 0.5, startsPaused: false)
        anchorEntity.addChild(ARentity)
        arView.scene.anchors.append(anchorEntity)
        return arView
    }
    func updateUIView(_ uiView: ARView, context: Context) {}
}


